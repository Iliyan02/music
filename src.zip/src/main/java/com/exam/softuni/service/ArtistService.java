package com.exam.softuni.service;

public interface ArtistService {


    void initArtists();

}
