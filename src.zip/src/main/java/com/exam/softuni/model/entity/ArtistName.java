package com.exam.softuni.model.entity;

public enum ArtistName {
    QUEEN, METALLICA, MADONNA
}
