package com.exam.softuni.model.entity;

public enum Genre {
    POP, ROCK, METAL, OTHER
}
