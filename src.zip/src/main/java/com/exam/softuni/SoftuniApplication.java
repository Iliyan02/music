package com.exam.softuni;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoftuniApplication {

    public static void main(String[] args) {
        SpringApplication.run(SoftuniApplication.class, args);
    }

}
