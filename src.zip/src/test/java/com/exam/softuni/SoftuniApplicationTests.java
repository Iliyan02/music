package com.exam.softuni;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoftuniApplicationTests {

    @Test
    void contextLoads() {
    }

}
